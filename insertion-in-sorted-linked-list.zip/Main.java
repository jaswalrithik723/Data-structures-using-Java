import java.util.*;
public class Main
{
    public class Node 
    {
        int data;
        Node next;
        Node(int d)
        {
            data=d;
            next=null;
        }
    }
    Node head=null;
    void display()
    {
        Node n=head;
        if(head==null)
        System.out.println("List is empty");
        else 
        {
            while(n!=null)
            {
                System.out.print(n.data+" ");
                n=n.next;
            }
        }
        System.out.println("\================");
    }
    void insertsort(int data)
    {
        Node temp=new Node(data);
        int tag=0;
        if(head==null)
        head=temp;
        else if(temp.data<head.data)
        {
            temp.next=head;
            head=temp;
        }
        else{
            Node n=head;
            while((n.next!=null)&&(temp.data>n.next.data))
                n=n.next;
            if(n.next==null)
                    tag=1;
            if(tag==0)
            {
                temp.next=n.next;
                n.next=temp;
            }
            else
            {
                n.next=temp;
            }
        }
    }
	public static void main(String[] args) {
	    System.out.println("Enter the elements");
		Scanner sc=new Scanner(System.in);
		Main ob=new Main();
		char c='y';
		System.out.println("Enter data, type n to stop");
		do{
		System.out.println("Enter the data");
		int d=sc.nextInt();
		ob.insertsort(d);
		System.out.println("Enter y or n");
		c=sc.next().toCharArray()[0];
		ob.display();
		}
		while(c!='n');
	}
}
