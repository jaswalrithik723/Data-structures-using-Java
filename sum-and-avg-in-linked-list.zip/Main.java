import java.util.*;
public class Main
{
    class Node{
        int data;
        Node next;
        Node(int d)
        {
            data=d;
            next=null;
        }
    }
    Node head=null;
    public void insert(int d)
    {
        Node temp=new Node(d);
        if(head==null)
        head=temp;
        else
        {
            temp.next=head;
            head=temp;
        }
    }
    public int som()
    {
        int sum=0;
        Node n=head;
        if(head==null)
        return 0;
        else{
            while(n!=null)
            {
                sum=sum+n.data;
                n=n.next;
            }
            return sum;
        }
    }
    public int num()
    {
        int count=0;
        Node n=head;
        if(head==null)
        return 0;
        else{
            while(n!=null)
            {
                count++;
                n=n.next;
            }
            return count;
        }
    }
	public static void main(String[] args) {
	    Main ob=new Main();
	    Scanner sc=new Scanner(System.in);
	    int d,sum=0,count=0;
	    float avg=0;
	    char c='y';
	    do
	    {
		System.out.println("Enter an element");
		d=sc.nextInt();
		ob.insert(d);
		System.out.println("Do you want to enter another. Type y for yes or n for n");
		c=sc.next().toCharArray()[0];
	    }
	    while(c!='n');
	    sum=ob.som();
	    System.out.println("Sum of this list is "+sum);
	    count=ob.num();
	    avg=(float)sum/count;
	    System.out.println("Average of this list is "+avg);
	}
}
