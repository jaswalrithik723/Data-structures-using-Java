import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.nextLine();
		char arr1[]=s.toCharArray();
		int arr2[]=new int[26];
		int arr3[]=new int[26];
		char c;
		int d;
		for(int i=0;i<arr1.length;i++)
		{
		    c=arr1[i];
		    if((c>64)&&(c<91))
		    {
		        d=(int)c-65;
		        arr2[d]++;
		    }
		    else if((c>96)&&(c<123))
		    {
		        d=(int)c-97;
		        arr3[d]++;
		    }
		    else;
		 }
		 for(int i=0;i<26;i++)
		 {
		     if(arr2[i]!=0)
		     {
		         d=i+65;
		         c=(char)d;
		     System.out.println(c+" apperas "+arr2[i]+" number of times");
		     }
		 }
		 for(int i=0;i<26;i++)
		 {
		     if(arr3[i]!=0)
		     {
		         d=if+97;
		         c=(char)d;
		     System.out.println(c+" apperas "+arr3[i]+" number of times");
		     }
		 }
	}
}
