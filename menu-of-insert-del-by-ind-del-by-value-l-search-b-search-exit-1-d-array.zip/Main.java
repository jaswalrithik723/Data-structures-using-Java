import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
		System.out.println("Enter the size of an array");
		Scanner sc=new Scanner(System.in);
		int size=sc.nextInt();
		int tag=0,count=0,lp=0;
		int arr[]=new int[size*10];
		int ind,elem;
		System.out.println("Enter the elements");
		for(int i=0;i<size;i++)
		arr[i]=sc.nextInt();
		do
		{
		    System.out.println("\n\nMenu\n");
		    System.out.println("1.Insert\n2.Delete by index\n3.Delete by value\n4.Linear Search\n5.Binary Search\n6.Exit");
		    System.out.println("Select a choice");
		    tag=sc.nextInt();
		    switch(tag)
		    {
		        case 1:
		            System.out.println("Enter the element and the index to insert");
		            elem=sc.nextInt();
		            ind=sc.nextInt();
		            if(ind>100)
		            System.out.println("Size exceeds the array limit");
		            else
		            {
		            if(ind<size)
		            {
		            for(int i=size-1;i>ind-1;i--)
		                arr[i+1]=arr[i];
		                size++;
		            arr[ind]=elem;
		            }
		            else{
		                arr[ind]=elem;
		                size=ind+1;
		            }
		            }
		            System.out.println("New array is");
		            for(int i=0;i<size;i++)
		            System.out.print(arr[i]+" ");
		            break;
		        case 2:
		            System.out.println("Enter the index to delete");
		            ind=sc.nextInt();
		            if(ind<size)
		            {
		            for(int i=ind;i<size-1;i++)
		                arr[i]=arr[i+1];
		            size--;
		            }
		            System.out.println("New array is");
		            for(int i=0;i<size;i++)
		            System.out.print(arr[i]+" ");
		            break;
		        case 3:
		            System.out.println("Enter the element to delete");
		            ind=sc.nextInt();
		            for(int i=0;i<size;i++)
		            {
		                if(arr[i]==ind)
		                {
		                    for(int j=i;j<size-1;j++)
		                    arr[j]=arr[j+1];
		                    size--;
		                    i--;
		                 }
		            }
		            System.out.println("New array is");
		            for(int i=0;i<size;i++)
		            System.out.print(arr[i]+" ");
		            break;
		            
		        case 4: 
		            System.out.println("Enter the element to search");
		            ind=sc.nextInt();
		            tag=0;
		            lp=0;
		            for(int i=0;i<size;i++)
		            {
		               if(arr[i]==ind)
		               {
		                   tag=1;
		                   lp=i;
		                   break;
		               }
		            }
		            if(tag==1)
		            System.out.println("Element at index "+lp);
		            else
		            System.out.println("Not found");
		            break;
		        case 5:
		            tag=0;
		            System.out.println("\nEnter the element to search");
                    int key=sc.nextInt();
                    int beg=0;
                    int end=size-1;
                    int mid=(beg+end)/2;
                    while(beg<=end)
                    {
                        if(arr[mid]==key)
                        {
                            tag=1;
                            break;
                        }
                        else if(arr[mid]>key)
                            end=mid-1;
                        else if(arr[mid]<key)
                            beg=mid+1;
                        mid=(beg+end)/2;    
                    }
                    if(tag==1)
                    System.out.println("Element found at "+mid+" index in this sorted array");
                    else
                    System.out.println("Element not found in this array");
                    break;
		        case 6: 
		            count=1;
		            break;
		    }
		 }
		 while(count==0);
	}
}



