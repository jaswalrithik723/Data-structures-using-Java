import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of rows and columns");
		int row=sc.nextInt();
		int col=sc.nextInt();
		int arr[][]=new int[row][col];
		System.out.println("Enter the elements");
		for(int i=0;i<row;i++)
		for(int j=0;j<col;j++)
		arr[i][j]=sc.nextInt();
		calc obj=new calc();
		obj.rightdiag(row,col,arr);
		obj.leftdiag(row,col,arr);
	}
}
class calc
{
	 void rightdiag(int row,int col,int arr[][])
	{
	    System.out.println("\nLeft diagnal elements are-");
	    for(int i=0;i<row;i++)
	    for(int j=0;j<col;j++)
	    if(i==j)
	    System.out.print(arr[i][j]+" ");
	}
     void leftdiag(int row,int col,int arr[][])
	{
	    System.out.println("\nRight diagnal elements are-");
	    for(int i=0;i<row;i++)
	    for(int j=0;j<col;j++)
	    if(i+j==col-1)
	    System.out.print(arr[i][j]+" ");
	}
}
