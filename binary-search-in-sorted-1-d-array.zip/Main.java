import java.util.*;
public class Main {
    public static void main(String args[])
    {
        int tag=0,ab=0;
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size of array");
        int size=sc.nextInt();
        int arr[]=new int[size];
        System.out.println("Enter the elements(in ascending order)");
        for(int i=0;i<size;i++)
            arr[i]=sc.nextInt();
        System.out.println("\nEnter the element to search");
        int key=sc.nextInt();
        int beg=0;
        int end=size-1;
        int mid=(beg+end)/2;
        while(beg<=end)
        {
            if(arr[mid]==key)
            {
                tag=1;
                break;
            }
            else if(arr[mid]>key)
                end=mid-1;
            else if(arr[mid]<key)
                beg=mid+1;
            mid=(beg+end)/2;    
        }
        if(tag==1)
        System.out.println("Element found at "+mid+" index in this sorted array");
        else
        System.out.println("Element not found in this array");
        
    }
}
