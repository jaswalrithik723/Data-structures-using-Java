import java.util.*;
public class Main
{
    class Node{
        int data;
        Node next;
        Node(int d)
        {
            data=d;
            next=null;
        }
    }
    Node head=null;
    public void insertbeg(int data)
    {
        Node temp=new Node(data);
        if(head==null)
        head=temp;
        else{
            temp.next=head;
            head=temp;
        }
    }
    public void display()
    {
        Node current=head;
        if(head==null)
        System.out.println("List is Empty");
        else
        {
            while(current!=null)
            {
                System.out.print(current.data+" ");
                current=current.next;
            }
        }
    }
	public static void main(String[] args) {
	    System.out.println("Insertind nodes at begining");
	    Scanner sc=new Scanner(System.in);
		Main ob=new Main();
		char c='y';
		System.out.println("Enter data, type n to stop");
		do{
		System.out.println("Enter the data");
		int d=sc.nextInt();
		ob.insertbeg(d);
		System.out.println("Enter y or n");
		c=sc.next().toCharArray()[0];
		}
		while(c!='n');
		ob.display();
	}
}
