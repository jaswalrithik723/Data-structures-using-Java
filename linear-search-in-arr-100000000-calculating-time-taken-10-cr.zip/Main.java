import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner sc=new Scanner(System.in);
		int arr[]=new int[100000000];  //array of 100000000 size(10 crore)
		Random ran=new Random();    // creating a random object
		for(int i=0;i<arr.length;i++)
		arr[i]=ran.nextInt(500);   //assigned random value from 0 to 499
		int key,flag=0,j=0;
		System.out.println("Enter the element to search in an array of 10000 elements");
	    key=sc.nextInt();           //searching a element using linear search in large array
	    double start = System.currentTimeMillis();
		for(int i=0;i<arr.length;i++)
		if(key==arr[i])
		{
		    flag=1;
		    j=i;
		    break;
		}
		double end = System.currentTimeMillis();
		if(flag==0)
		System.out.println("Number Not found");
		else
		System.out.println(j);
		System.out.println("Time " + (float)(end - start)/1000 + "s"); 
	}
}

