import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		char rand=1000;
		char c;
		int count;
		char arr[]=s.toCharArray();
		Arrays.sort(arr);
		for(int i=0;i<arr.length;i++)
		{
		   count=0;
		   c=arr[i]; 
		    if((c>65&&c<90)||(c>97&&c<122))
		    {
		        for(int j=0;j<arr.length;j++)
		        if(arr[j]==c)
		        {
		        count++;
		        arr[j]=rand;
		        }
		        System.out.println(c+" appears "+count+" number of times");
		    }
		 }
	}
}
