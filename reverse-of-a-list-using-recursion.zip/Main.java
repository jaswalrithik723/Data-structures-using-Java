import java.util.*;
public class Main
{
    public class Node 
    {
        int data;
        Node next;
        Node(int d)
        {
            data=d;
            next=null;
        }
    }
    static Node head=null;
    public void display()
    {
        Node n=head;
        if(head==null)
        System.out.println("String is empty");
        else
        {
            while(n!=null)
            {
            System.out.print(n.data+" ");
            n=n.next;
            }
            System.out.println("\n==========");
        }
    }
    public void insert(int d)
    {
        Node temp=new Node(d);
        if(head==null)
        head=temp;
        else
        {
            temp.next=head;
            head=temp;
        }
    }
    public void reverse(Node head)
    {
        if(head==null);
        else
        {
            reverse(head.next);
        System.out.print(head.data+" ");
        }
    }
	public static void main(String[] args) {
		System.out.println("Reverse of linked list");
	    Scanner sc=new Scanner(System.in);
		Main ob=new Main();
		char c='y';
		System.out.println("Enter y or n");
		c=sc.next().toCharArray()[0];
		while(c!='n')
		{
		System.out.println("Enter the data");
		int d=sc.nextInt();
		ob.insert(d);
		System.out.println("Enter y or n");
		c=sc.next().toCharArray()[0];
		}
		ob.display();
		ob.reverse(head);
	}
}
