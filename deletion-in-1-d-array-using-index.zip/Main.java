import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int arr[]=new int[100];
		System.out.println("Enter the size of an array");
		int size=sc.nextInt();
		System.out.println("Enter the elements");
		for(int i=0;i<size;i++)
		arr[i]=sc.nextInt();
	    System.out.println("Enter the index to delete");
	    int ind=sc.nextInt();
	    if(ind<size)
	    {
	    for(int i=ind;i<size;i++)
	    arr[i]=arr[i+1];
	    size--;
	    }else;
	    for(int i=0;i<size;i++)
	    System.out.print(arr[i]+" ");
	}
}
