import java.util.*;
public class Main
{
    class Node{
        int data;
        Node next;
        Node(int d)
        {
            data=d;
            next=null;
        }
    }
    Node head=null;
    public void insertbeg(int data)
    {
        Node temp=new Node(data);
        if(head==null)
        head=temp;
        else{
            temp.next=head;
            head=temp;
        }
    }
    public void insertend(int data)
    {
        Node temp=new Node(data);
        Node n=head;
        if(head==null)
        head=temp;
        else
        {
            while(n.next!=null)
            n=n.next;
            n.next=temp;
        }
    }
    public void insertanywhere(int data,int index)
    {
        Node temp=new Node(data);
        Node n=head;
        if((head==null)&&(index==1))
        head=temp;
        else if((head==null)&&(index>1))
        System.out.println("Cant be inserted after null");
        else{
        for(int i=1;i<index;i++)
        n=n.next;
        if(n==null)
        System.out.println("Cant be inserted after null");
        else{
        Node n1=n.next;
        n.next=temp;
        temp.next=n1;
        }
        }
    }
    public void deletebeg()
    {
        Node n=head;
        if(head==null)
        System.out.println("List is already empty");
        else{
            Node temp=head;
            head=head.next;
            temp=null;
        }
    }
    public void deleteend()
    {
        Node n=head;
        if(head==null)
        System.out.println("List is already empty");
        else if(n.next==null)
        {
            Node temp=head;
            head=null;
            temp=null;
        }
        else {
            while(n.next.next!=null)
            n=n.next;
            Node last=n.next;
            n.next=null;
            last=null;
            }
    }
    public void deletevalue(int value)
    {
        Main ob=new Main();
        Node n=head;
        if(head==null)
        System.out.println("List is empty");
        else if(n.next==null)
        {
            if(n.data==value)
            {
                Node temp1=head;
                head=null;
                temp1=null;
            }
        }
        else
        {
            while(n.next!=null)
            {
                if(n.next.data==value)
                {
                    if(n.next.next==null)
                    {
                        n.next=null;
                    }
                    else
                    {
                        Node temp=n.next;
                        n.next=n.next.next;
                        temp=null;
                    }
                    break;
                }
            }
        }
    }
    public void display()
    {
        Node n=head;
        while(n!=null)
        {
            System.out.print(n.data+" ");
            n=n.next;
        }
        System.out.println();
    }
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Main ob=new Main();
		System.out.println("________MENU________");
		System.out.println("1.Insert at Begining\n2.Insert at End.\n3.Insert after given node");
		System.out.println("4.Delete from begining\n5.Delete from end\n6.Delete by value(first match)");
		int choice=0,d=0;
		while(choice!=7)
		{
		System.out.println("Select your choice");
		choice=sc.nextInt();
		switch(choice)
		{
		    case 1:
		        System.out.println("Enter the data");
		        d=sc.nextInt();
		        ob.insertbeg(d);
		        ob.display();
		        System.out.println("==================");
		        break;
		    case 2:
		        System.out.println("Enter the data");
		        d=sc.nextInt();
		        ob.insertend(d);
		        ob.display();
		        System.out.println("==================");
		        break;
		     case 3:
		        System.out.println("Enter the data");
		        d=sc.nextInt();
		        System.out.println("Enter the index after which you want to insert(index start from 1)");
		        int ind=sc.nextInt();
		        ob.insertanywhere(d,ind);
		        ob.display();
		        System.out.println("==================");
		        break;
		     case 4:
		         ob.deletebeg();
		         ob.display();
		         System.out.println("==================");
		         break;
		     case 5:
		         ob.deleteend();
		         ob.display();
		         System.out.println("==================");
		         break;
		     case 6:
		         System.out.println("Enter the value you want to delete");
		         d=sc.nextInt();
		         ob.deletevalue(d);
		         ob.display();
		         System.out.println("==================");
		         break;
		}
		    
		}
	}
}

