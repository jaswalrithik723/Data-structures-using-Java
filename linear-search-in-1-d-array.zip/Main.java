import java.util.*;
public class Main {
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int arr[]=new int[100];
        int tag=0,j=0;
        System.out.println("Enter the number of elements");
        int n=sc.nextInt();
        System.out.println("Enter the elements");
        for(int i=0;i<n;i++)
            arr[i]=sc.nextInt();
        System.out.println("Enter the element to search");
        int ser=sc.nextInt();
        for(int i=0;i<n;i++)
        if(arr[i]==ser)
        {
            tag=1;
            j=i;
            break;
        }
        if(tag==0)
        System.out.println("Element not found");
        else
        System.out.println("Element found at "+j+" index ");
    }
}