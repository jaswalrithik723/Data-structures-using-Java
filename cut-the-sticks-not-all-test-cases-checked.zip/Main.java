import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    calc obj=new calc();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of sticks");
		int size=sc.nextInt();
		int sm=9999,larg=-9999,count=0;
		if(size==0)
		System.out.println("Enter number greater than zero");
		else
		{
		int arr[]=new int[size];
		System.out.println("Enter the length of sticks");
		obj.arrscan(size,arr);
		sm=obj.smllest(size,arr);
		if(sm<0)
		    System.out.println("Size cant be negative");
		else 
		{
		    larg=obj.lrgest(size,arr);
		    while(larg>0)
		    {
		        count=0;
		        sm=9999;
		        for(int i=0;i<size;i++)
		        if((arr[i]<sm)&&arr[i]!=0)
		        sm=arr[i];
		        for(int i=0;i<size;i++)
		        {
		            if(arr[i]>0)
		            {
		            arr[i]=arr[i]-sm;
		            count++;
		            }
		        }
		        System.out.println(count);
		        larg=obj.lrgest(size,arr);
		    }
		  }
	   }
    }
}
class calc
{
    Scanner sc1=new Scanner(System.in);
    void arrscan(int size,int arr[])
    {
        for(int i=0;i<size;i++)
		arr[i]=sc1.nextInt();
    }
    int smllest(int size,int arr[])
    {
        int sm=9999;
        for(int i=0;i<size;i++)
		if(arr[i]<sm)
		sm=arr[i];
		return sm;
    }
    int lrgest(int size,int arr[])
    {
        int larg=-9999;
        for(int i=0;i<size;i++)
		    if(arr[i]>larg)
		    larg=arr[i];
		    return larg;
    }
}
