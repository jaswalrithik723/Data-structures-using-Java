import java.util.*;
public class Main
{
    class Node{
        int data;
        Node next;
        Node(int d)
        {
            data=d;
            next=null;
        }
    }
    Node head=null;
    public void insertbeg(int data)
    {
        Node temp=new Node(data);
        if(head==null)
        head=temp;
        else{
            temp.next=head;
            head=temp;
        }
    }
    public void display()
    {
        Node current=head;
        if(head==null)
        System.out.println("List is Empty");
        else
        {
            while(current!=null)
            {
                System.out.print(current.data+" ");
                current=current.next;
            }
        }
    }
    public int listlen()
    {
        Node n=head;
        int count=0;
        if(head==null)
        return 0;
        else{
            while(n!=null)
            {
                count++;
                n=n.next;
            }
        }
        return count;
    }
    public void deleteind(int ind,int count)
    {
        Node n=head;
        if(ind==1)
        {
            if(count==1)
            {
                head=null;
            }
            else{
                head=head.next;
            }
        }
        else{
        for(int i=1;i<ind-1;i++)
        {
            n=n.next;
        }
            n.next=n.next.next;
        }
    }
	public static void main(String[] args) {
		System.out.println("=============Deleting by index=============");
	    Scanner sc=new Scanner(System.in);
		Main ob=new Main();
		char c='y';
		System.out.println("Enter data, type n to stop");
		System.out.println("Enter y or n");
		c=sc.next().toCharArray()[0];
		while(c!='n')
		{
		System.out.println("Enter the data");
		int d=sc.nextInt();
		ob.insertbeg(d);
		System.out.println("Enter y or n");
		c=sc.next().toCharArray()[0];
		}
		char rc='y';
		while(rc=='y')
		{
		int len=ob.listlen();
		if(len==0)
		{
		System.out.println("\nList is empty");
		break;
		}
		else{
		ob.display();
		System.out.println("\nEnter the index to delete");
		int index=sc.nextInt();
		if(index==0)
		System.out.println("\nIndex starts from 1, Enter valid index");
		else if(index>len)
		System.out.println("\nIndex exceeds list length");
		else
		ob.deleteind(index,len);
		ob.display();
	    len=ob.listlen();
		if(len==0)
		break;
		else{
		System.out.println("\nDo you want to delete again");
		rc=sc.next().toCharArray()[0];
		}
		}
		}
	}
}
